export default function quadrado(num){
    return num * num;
}

export function metade(num){
    return num / 2;
}

export const MEUPI = 3.415678;

