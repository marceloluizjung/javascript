const nome = 'Programação em JavaScript';
const preco = 'R$ 27,99';
const horas = 25;

const curso = {
    nome,
    preco,
    instrutor: 'Geek University',
    carga_horaria: horas,
};

console.log(curso);
