export function soma(num1, num2){
    return num1 + num2;
}

export function subtracao(num1, num2){
    return num1 - num2;
}
