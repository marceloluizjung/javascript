export default function dobrar(num){
    return num * 2;
}
