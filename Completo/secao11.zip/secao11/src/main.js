// import { soma as somarMais, subtracao } from './helper';
// import dobrar from './dobrar';
// import quadrado, { metade, MEUPI } from './funcoes';

// import * as helpers from './helper';

// console.log(somarMais(40, 2));
// console.log(subtracao(82, 40));
// console.log(dobrar(8));

// console.log(quadrado(7));
// console.log(metade(8));
// console.log(MEUPI);


// console.log(helpers.soma(5, 9));
// console.log(helpers.subtracao(9, 4));
document.querySelector('body').style.background = 'blue';
